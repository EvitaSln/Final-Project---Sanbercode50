module.exports = {
    datatest: {
        email: 'slnsari02@gmail.com',
        password: 'Taurus12345!',
        name: 'Evita Silaen'
    },

    datatest1: {
        email: 'slnsari02@gmail.com',
        password: '12345'
    },
}