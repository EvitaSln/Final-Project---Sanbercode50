module.exports = {
    datatestid: {
        dashboard_title_text: '//*[@class="mb-sm-0 font-size-18"]',
        dashboard_user_area_dropdown: '//*[@class="rounded-circle header-profile-user"]',
        dashboard_user_picture: '//*[@class="img-thumbnail rounded-circle"]',
        dashboard_user_name: '//*[@id="page-header-user-dropdown"]'
    }
}