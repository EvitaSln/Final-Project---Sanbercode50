module.exports = {
    datatestid: {
        logo: '//*[@class="auth-logo-dark"]',
        usr_input: '//*[@name="email"]',
        pass_input: '//*[@name="password"]',
        btn_submit: '//*[contains(@type, "submit")]',
        err_login_message: '//*[contains(@class, "alert alert-danger text-center mb-4 flash")]',
        err_login_message1: '//*[contains(@class, "alert alert-danger text-center mb-4 flash"]'
    }
}